javac -cp commons-codec-1.4.jar AesTest.java
sleep 5
java -cp .:./commons-codec-1.4.jar AesTest $1
