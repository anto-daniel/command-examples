#!/bin/bash
# Ingest files

if [ -n "$1" ]; 
then

for k in $@
do
	i=$(sha1sum $k | awk '{print $1}')
	echo "sha1sum is" $i
	j=$(./keygen.sh $i)
	echo "checksum is" $j
	curl -X POST --digest -u "ingest:facetime" "https://drtenant03/cxf/actiance/apc/dig/ingestion/transcript?Version=1&Connection=$j" --insecure --data-binary @$k
done
else
	echo "ERROR: No file is specified"
	echo "Usage is ./ingest.sh /path/of/the/filename/*"
fi
