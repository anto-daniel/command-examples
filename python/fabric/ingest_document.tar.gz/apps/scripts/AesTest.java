import org.apache.commons.codec.binary.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLEncoder;

public class AesTest{

	public static void main(String[] args){
		try{
			//String _key="1bcedbf7a680ea2f";
			String _key="d70580f9984d7496";
			//String  input ="SchemaVersion=1.0&Checksum="+args[0]+"&ClusterID=test1";
			String  input ="SchemaVersion=1.0&Checksum="+args[0]+"&ClusterID=drtest";
			Cipher cipher=Cipher.getInstance("AES/ECB/PKCS5Padding");
			final SecretKeySpec secretKey = new SecretKeySpec(_key.getBytes(),"AES");
			cipher.init(Cipher.ENCRYPT_MODE,secretKey);
			byte[] encVal = cipher.doFinal(input.getBytes("UTF-8"));
			String parameters = Base64.encodeBase64String(encVal);
			System.out.println(URLEncoder.encode(parameters,"UTF-8"));
		}catch(Exception e){
			e.printStackTrace(); 
		}

	}


}
